# Web3D Engine — Aşama 1 (MVP Çekirdek)

Tarayıcıda gerçekten çalışan, WebGL2 tabanlı, TypeScript ile yazılmış bir mini
3D game engine / editör. Render pipeline ve scene graph için Babylon.js
(@babylonjs/core) kullanılır — ama sahne, entity, component, seçim, gizmo,
undo-uyumlu play/stop döngüsü gibi tüm **editör mantığı kendi kodumuzdadır**.
Babylon burada sadece GPU'ya çizim yapan gerçek bir render motoru olarak
kullanılıyor; hiçbir buton veya panel sahte/mockup değildir.

## Çalıştırma

```bash
npm install
npm run dev       # http://localhost:5173
```

Production build:

```bash
npm run build      # tsc ile tip kontrolü + vite build
npm run preview
```

> Bu kod bir sandbox'ta (internet erişimi olmayan bir container) yazıldı;
> `npm install` bu ortamda çalıştırılıp doğrulanamadı. Kodun tamamı
> Babylon.js v7 API'sine göre dikkatlice yazıldı, ancak ilk `npm run dev`
> sonrası bir TypeScript/derleme hatası çıkarsa (paket sürüm uyuşmazlığı vb.)
> hatayı bana yapıştırman yeterli — hemen düzeltirim.

## Şu an gerçekten çalışan özellikler (Aşama 1)

- Gerçek WebGL2 render pipeline + render loop (`EngineCore`)
- Gerçek scene graph: her `Entity` bir Babylon `TransformNode`'a sahiptir,
  parent/child ilişkisi gerçek node parenting ile kurulur
- Component sistemi: `Transform`, `MeshRenderer`, `Camera`, `Light`
  (Directional/Point/Spot/Ambient)
- Create menüsünden 7 primitive (Cube, Sphere, Plane, Cylinder, Capsule,
  Cone, Torus) + Empty Entity + Camera + 4 ışık tipi — hepsi gerçekten
  sahneye ekleniyor
- Gerçek raycasting ile obje seçimi (tekli + Shift ile çoklu), bounding box,
  highlight
- Gerçek Position/Rotation/Scale gizmo'ları (Babylon `UtilityLayerRenderer`
  tabanlı), grid snapping
- Hierarchy paneli gerçek scene graph ile birebir bağlı (seçim, çift tık
  rename, sağ tık Delete context menu)
- Inspector paneli seçili entity'nin component'lerine göre **dinamik**
  oluşur; her alan değişikliği anında sahneye yansır (ve tam tersi — gizmo
  ile sürüklediğinde Inspector anında güncellenir)
- Play Mode: basılınca tüm transform'ların anlık görüntüsü alınır, izole bir
  `requestAnimationFrame` döngüsü başlar, sahnede Camera component'i varsa
  aktif kamera olur; Stop'a basınca transformlar birebir geri yüklenir
- Console paneli: `console.log/info/warn/error` gerçekten hook'lanır,
  runtime hataları (`window.onerror`) burada görünür
- WASD + sağ-tık ile kamera fly, sol-drag orbit, tekerlek zoom, sağ-drag pan
  (Babylon `ArcRotateCamera`), Perspective/Orthographic geçişi
  Wireframe/Shaded geçişi
- Kısayollar: `Q` Select, `W` Translate, `E` Rotate, `R` Scale, `F` Focus,
  `Delete` sil
- Panel genişlikleri gerçek sürükle-bırak ile yeniden boyutlandırılabilir

## Aşama 2'de eklenecekler (henüz yok — sahte göstermiyoruz)

Kullanıcı talimatındaki sırayla:

1. **Physics** — Rapier entegrasyonu (Rigidbody, Box/Sphere/Capsule Collider,
   gravity, collision/trigger)
2. **Asset Browser** — gerçek dosya import (drag&drop + file picker),
   `.glb/.gltf` import (`@babylonjs/loaders`), texture/HDR desteği,
   IndexedDB tabanlı asset metadata
3. **Materials** — PBR material sistemi (metallic/roughness/emissive/normal
   map), gerçek texture pipeline
4. **Scripting** — `class X extends Script { awake/start/update/destroy }`
   lifecycle, Input API (keyboard/mouse/pointer), Play Mode loop'una bağlanma
5. **Serialization** — Scene JSON formatı, Save/Load/Duplicate/Rename/New
   Scene, IndexedDB persistence
6. **Undo/Redo** — Command pattern tabanlı gerçek history sistemi (object
   creation/deletion, transform, rename, component ekleme/silme)

Bu aşamalar mevcut mimariye (SceneGraph / EditorStore / component sistemi)
oturacak şekilde tasarlandı — örn. `PlayModeController` şimdiden script
`update(dt)` çağrılarını bağlayabileceğimiz izole bir loop çalıştırıyor.

## Mimari

```
src/
├── core/            EventEmitter, id üretici, dom yardımcıları
├── scene/            Entity, SceneGraph (gerçek scene graph)
├── components/       Transform, MeshRenderer, Camera, Light
├── engine/           EngineCore (renderer), PrimitiveFactory,
│                     SelectionManager, GizmoController
├── state/            EditorStore (reaktif merkezi state)
├── runtime/          PlayModeController (izole play/stop döngüsü)
├── editor/
│   ├── viewport/      Viewport (kısayollar, stats overlay)
│   ├── hierarchy/      HierarchyPanel
│   ├── inspector/      InspectorPanel
│   ├── console/        ConsolePanel
│   └── layout/         ResizableSplitter
└── main.ts           Bootstrap + WebGL2 kontrolü + global hata yakalama
```

Editor state (`EditorStore`) ile sahne durumu (`SceneGraph`) ayrıdır; tüm
paneller bunlara abone olur ve değişiklikler tek yönlü, gerçek event'ler
üzerinden yayılır (mockup binding yok).
