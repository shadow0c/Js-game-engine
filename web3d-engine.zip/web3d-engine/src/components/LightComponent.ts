import {
  Scene,
  TransformNode,
  DirectionalLight,
  PointLight,
  SpotLight,
  HemisphericLight,
  Vector3,
  Color3
} from '@babylonjs/core';

export type LightKind = 'directional' | 'point' | 'spot' | 'ambient';
export type EngineLight = DirectionalLight | PointLight | SpotLight | HemisphericLight;

export class LightComponent {
  readonly kind: LightKind;
  readonly light: EngineLight;

  constructor(scene: Scene, private node: TransformNode, kind: LightKind, name: string) {
    this.kind = kind;
    switch (kind) {
      case 'directional':
        this.light = new DirectionalLight(`${name}_light`, new Vector3(0, -1, 0), scene);
        break;
      case 'point':
        this.light = new PointLight(`${name}_light`, Vector3.Zero(), scene);
        break;
      case 'spot':
        this.light = new SpotLight(`${name}_light`, Vector3.Zero(), new Vector3(0, -1, 0), Math.PI / 3, 2, scene);
        break;
      case 'ambient':
      default:
        this.light = new HemisphericLight(`${name}_light`, new Vector3(0, 1, 0), scene);
        break;
    }
    this.light.diffuse = new Color3(1, 1, 1);
    this.light.intensity = 1;
    this.syncFromNode();
  }

  get color(): Color3 {
    return this.light.diffuse;
  }
  set color(value: Color3) {
    this.light.diffuse = value;
  }

  get intensity(): number {
    return this.light.intensity;
  }
  set intensity(value: number) {
    this.light.intensity = value;
  }

  get range(): number {
    if (this.light instanceof PointLight || this.light instanceof SpotLight) return this.light.range;
    return 0;
  }
  set range(value: number) {
    if (this.light instanceof PointLight || this.light instanceof SpotLight) this.light.range = value;
  }

  /** Entity'nin transform'u değiştiğinde çağrılır: pozisyon ve yön dünya matrisinden hesaplanır. */
  syncFromNode(): void {
    this.node.computeWorldMatrix(true);
    const position = this.node.getAbsolutePosition();

    if (this.light instanceof PointLight || this.light instanceof SpotLight) {
      this.light.position.copyFrom(position);
    }
    if (this.light instanceof DirectionalLight || this.light instanceof SpotLight) {
      const forward = Vector3.TransformNormal(new Vector3(0, 0, 1), this.node.getWorldMatrix());
      forward.normalize();
      this.light.direction = forward;
    }
  }

  dispose(): void {
    this.light.dispose();
  }
}
