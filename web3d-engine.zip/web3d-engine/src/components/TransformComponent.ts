import { TransformNode, Vector3 } from '@babylonjs/core';
import { EventEmitter } from '../core/EventEmitter';

export interface TransformChangeEvent {
  position: Vector3;
  rotation: Vector3;
  scaling: Vector3;
}

export class TransformComponent extends EventEmitter<{ change: TransformChangeEvent }> {
  constructor(private node: TransformNode) {
    super();
  }

  get position(): Vector3 {
    return this.node.position;
  }
  set position(value: Vector3) {
    this.node.position.copyFrom(value);
    this.notify();
  }

  get rotation(): Vector3 {
    return this.node.rotation;
  }
  set rotation(value: Vector3) {
    this.node.rotation.copyFrom(value);
    this.notify();
  }

  get scaling(): Vector3 {
    return this.node.scaling;
  }
  set scaling(value: Vector3) {
    this.node.scaling.copyFrom(value);
    this.notify();
  }

  setPositionXYZ(x: number, y: number, z: number): void {
    this.node.position.set(x, y, z);
    this.notify();
  }

  setRotationXYZ(x: number, y: number, z: number): void {
    this.node.rotation.set(x, y, z);
    this.notify();
  }

  setScalingXYZ(x: number, y: number, z: number): void {
    this.node.scaling.set(x, y, z);
    this.notify();
  }

  /** Node dışarıdan (ör. gizmo drag) değiştirildiğinde manuel olarak çağrılır. */
  notify(): void {
    this.emit('change', {
      position: this.node.position,
      rotation: this.node.rotation,
      scaling: this.node.scaling
    });
  }
}
