import { Scene, TransformNode, UniversalCamera } from '@babylonjs/core';

/**
 * Entity üzerindeki gerçek bir oyun kamerası. Editör kamerasından bağımsızdır;
 * Play Mode'a girildiğinde sahnedeki ilk Camera component'i aktif kamera olur.
 */
export class CameraComponent {
  readonly camera: UniversalCamera;

  constructor(scene: Scene, private node: TransformNode, name: string) {
    this.node.computeWorldMatrix(true);
    this.camera = new UniversalCamera(`${name}_camera`, this.node.getAbsolutePosition().clone(), scene);
    this.camera.rotation.copyFrom(this.node.rotation);
    this.camera.metadata = { isEntityCamera: true };
  }

  get fov(): number {
    return this.camera.fov;
  }
  set fov(value: number) {
    this.camera.fov = value;
  }

  get nearClip(): number {
    return this.camera.minZ;
  }
  set nearClip(value: number) {
    this.camera.minZ = value;
  }

  get farClip(): number {
    return this.camera.maxZ;
  }
  set farClip(value: number) {
    this.camera.maxZ = value;
  }

  /** Entity'nin transform'u değiştiğinde çağrılır, kamerayı dünya pozisyonuna taşır. */
  syncFromNode(): void {
    this.node.computeWorldMatrix(true);
    this.camera.position.copyFrom(this.node.getAbsolutePosition());
    this.camera.rotation.copyFrom(this.node.rotation);
  }

  dispose(): void {
    this.camera.dispose();
  }
}
