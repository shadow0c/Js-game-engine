import { Mesh, Scene, StandardMaterial, Color3, TransformNode } from '@babylonjs/core';

export class MeshRendererComponent {
  readonly mesh: Mesh;
  readonly material: StandardMaterial;

  constructor(scene: Scene, node: TransformNode, mesh: Mesh) {
    this.mesh = mesh;
    this.mesh.parent = node;

    this.material = new StandardMaterial(`${node.name}_mat`, scene);
    this.material.diffuseColor = new Color3(0.68, 0.7, 0.75);
    this.material.specularColor = new Color3(0.15, 0.15, 0.15);
    this.mesh.material = this.material;
  }

  setWireframe(enabled: boolean): void {
    this.material.wireframe = enabled;
  }

  dispose(): void {
    this.material.dispose();
    this.mesh.dispose();
  }
}
