import {
  Engine,
  Scene,
  ArcRotateCamera,
  Vector3,
  Color3,
  Color4,
  HemisphericLight,
  AxesViewer,
  HighlightLayer,
  MeshBuilder
} from '@babylonjs/core';
import { GridMaterial } from '@babylonjs/materials';
import { isTypingTarget } from '../core/dom';

export class EngineCore {
  readonly engine: Engine;
  readonly scene: Scene;
  readonly editorCamera: ArcRotateCamera;
  readonly highlightLayer: HighlightLayer;

  private rightMouseHeld = false;

  constructor(private canvas: HTMLCanvasElement) {
    this.engine = new Engine(canvas, true, { stencil: true, preserveDrawingBuffer: true }, true);
    this.scene = new Scene(this.engine);
    this.scene.clearColor = new Color4(0.09, 0.1, 0.12, 1);

    this.editorCamera = new ArcRotateCamera(
      'editorCamera',
      -Math.PI / 3,
      Math.PI / 3,
      12,
      Vector3.Zero(),
      this.scene
    );
    this.editorCamera.lowerRadiusLimit = 0.5;
    this.editorCamera.wheelPrecision = 40;
    this.editorCamera.panningSensibility = 120;
    this.editorCamera.minZ = 0.05;
    this.editorCamera.attachControl(canvas, true);

    const ambient = new HemisphericLight('__editorAmbient', new Vector3(0, 1, 0), this.scene);
    ambient.intensity = 0.55;

    this.createGrid();
    new AxesViewer(this.scene, 2);
    this.highlightLayer = new HighlightLayer('selectionHighlight', this.scene);

    canvas.addEventListener('contextmenu', (e) => e.preventDefault());
    this.enableFlyControls(canvas);

    window.addEventListener('resize', () => this.engine.resize());
  }

  /** Sağ tık basılı tutularak WASD ile kamera hareketi (fly mode) yapılıyor mu? */
  get isFlying(): boolean {
    return this.rightMouseHeld;
  }

  private createGrid(): void {
    const ground = MeshBuilder.CreateGround('__editorGrid', { width: 60, height: 60 }, this.scene);
    const gridMat = new GridMaterial('__editorGridMat', this.scene);
    gridMat.majorUnitFrequency = 5;
    gridMat.minorUnitVisibility = 0.3;
    gridMat.gridRatio = 1;
    gridMat.mainColor = new Color3(0.32, 0.33, 0.38);
    gridMat.lineColor = new Color3(0.45, 0.47, 0.55);
    gridMat.opacity = 0.9;
    gridMat.backFaceCulling = false;
    ground.material = gridMat;
    ground.isPickable = false;
    ground.position.y = -0.001;
  }

  private enableFlyControls(canvas: HTMLCanvasElement): void {
    const pressed = new Set<string>();
    const speed = 8;

    canvas.addEventListener('pointerdown', (e) => {
      if (e.button === 2) this.rightMouseHeld = true;
    });
    window.addEventListener('pointerup', (e) => {
      if (e.button === 2) this.rightMouseHeld = false;
    });
    window.addEventListener('keydown', (e) => {
      if (isTypingTarget(e.target)) return;
      pressed.add(e.key.toLowerCase());
    });
    window.addEventListener('keyup', (e) => {
      pressed.delete(e.key.toLowerCase());
    });

    this.scene.onBeforeRenderObservable.add(() => {
      if (!this.rightMouseHeld || pressed.size === 0) return;
      const dt = this.engine.getDeltaTime() / 1000;
      const forward = this.editorCamera.target.subtract(this.editorCamera.position).normalize();
      const right = Vector3.Cross(forward, Vector3.Up()).normalize();
      const move = Vector3.Zero();
      if (pressed.has('w')) move.addInPlace(forward);
      if (pressed.has('s')) move.subtractInPlace(forward);
      if (pressed.has('d')) move.addInPlace(right);
      if (pressed.has('a')) move.subtractInPlace(right);
      if (move.lengthSquared() > 0) {
        move.normalize().scaleInPlace(speed * dt);
        this.editorCamera.target.addInPlace(move);
      }
    });
  }

  start(): void {
    this.engine.runRenderLoop(() => {
      this.scene.render();
    });
  }

  dispose(): void {
    this.engine.dispose();
  }
}
