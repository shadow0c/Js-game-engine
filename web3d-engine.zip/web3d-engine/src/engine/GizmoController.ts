import { UtilityLayerRenderer, PositionGizmo, RotationGizmo, ScaleGizmo, Scene, Node } from '@babylonjs/core';
import { EditorStore } from '../state/EditorStore';
import { SceneGraph } from '../scene/SceneGraph';

export type GizmoMode = 'select' | 'translate' | 'rotate' | 'scale';

export class GizmoController {
  private utilLayer: UtilityLayerRenderer;
  private positionGizmo: PositionGizmo;
  private rotationGizmo: RotationGizmo;
  private scaleGizmo: ScaleGizmo;
  private mode: GizmoMode = 'translate';
  private snapEnabled = false;
  private snapSize = 1;

  constructor(scene: Scene, private graph: SceneGraph, private store: EditorStore) {
    this.utilLayer = new UtilityLayerRenderer(scene);
    this.positionGizmo = new PositionGizmo(this.utilLayer);
    this.rotationGizmo = new RotationGizmo(this.utilLayer);
    this.scaleGizmo = new ScaleGizmo(this.utilLayer);

    [this.positionGizmo, this.rotationGizmo, this.scaleGizmo].forEach((gizmo) => {
      gizmo.updateGizmoRotationToMatchAttachedMesh = true;
    });

    this.registerDragSync(this.positionGizmo.xGizmo);
    this.registerDragSync(this.positionGizmo.yGizmo);
    this.registerDragSync(this.positionGizmo.zGizmo);
    this.registerDragSync(this.rotationGizmo.xGizmo);
    this.registerDragSync(this.rotationGizmo.yGizmo);
    this.registerDragSync(this.rotationGizmo.zGizmo);
    this.registerDragSync(this.scaleGizmo.xGizmo);
    this.registerDragSync(this.scaleGizmo.yGizmo);
    this.registerDragSync(this.scaleGizmo.zGizmo);

    this.store.on('selectionChanged', (ids) => this.attachToSelection(ids));
    this.setMode('translate');
  }

  private registerDragSync(axisGizmo: any): void {
    axisGizmo?.dragBehavior?.onDragObservable.add(() => this.notifySelectedTransform());
  }

  private notifySelectedTransform(): void {
    const [id] = this.store.selectedIds;
    const entity = id ? this.graph.entities.get(id) : undefined;
    entity?.transform.notify();
  }

  private attachToSelection(ids: string[]): void {
    const entity = ids.length > 0 ? this.graph.entities.get(ids[0]) : undefined;
    const node: Node | null = entity ? entity.node : null;
    this.positionGizmo.attachedNode = this.mode === 'translate' ? node : null;
    this.rotationGizmo.attachedNode = this.mode === 'rotate' ? node : null;
    this.scaleGizmo.attachedNode = this.mode === 'scale' ? node : null;
  }

  setMode(mode: GizmoMode): void {
    this.mode = mode;
    this.attachToSelection(this.store.selectedIds);
  }

  getMode(): GizmoMode {
    return this.mode;
  }

  setSnapEnabled(enabled: boolean): void {
    this.snapEnabled = enabled;
    this.positionGizmo.snapDistance = enabled ? this.snapSize : 0;
    this.rotationGizmo.snapDistance = enabled ? Math.PI / 12 : 0;
  }

  isSnapEnabled(): boolean {
    return this.snapEnabled;
  }

  setSnapSize(size: number): void {
    this.snapSize = size;
    if (this.snapEnabled) this.positionGizmo.snapDistance = size;
  }
}
