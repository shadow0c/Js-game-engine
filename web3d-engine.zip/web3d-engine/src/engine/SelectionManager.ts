import { PointerEventTypes, PointerInfo, AbstractMesh, Color3 } from '@babylonjs/core';
import { EngineCore } from './EngineCore';
import { SceneGraph } from '../scene/SceneGraph';
import { EditorStore } from '../state/EditorStore';

export class SelectionManager {
  constructor(private engineCore: EngineCore, private graph: SceneGraph, private store: EditorStore) {
    this.engineCore.scene.onPointerObservable.add((info: PointerInfo) => {
      if (info.type !== PointerEventTypes.POINTERPICK) return;
      const mesh = info.pickInfo?.pickedMesh ?? null;
      this.handlePick(mesh, info.event as PointerEvent);
    });

    this.store.on('selectionChanged', (ids) => this.applyHighlight(ids));
  }

  private handlePick(mesh: AbstractMesh | null, event: PointerEvent): void {
    if (!mesh || !mesh.isPickable) {
      if (!event.shiftKey) this.store.setSelection([]);
      return;
    }

    const entityId = mesh.parent?.metadata?.entityId as string | undefined;
    if (!entityId) return;

    if (event.shiftKey) {
      this.store.toggleSelection(entityId);
    } else {
      this.store.setSelection([entityId]);
    }
  }

  private applyHighlight(ids: string[]): void {
    this.engineCore.highlightLayer.removeAllMeshes();
    this.graph.entities.forEach((entity) => {
      const mesh = entity.components.meshRenderer?.mesh;
      if (!mesh) return;
      const isSelected = ids.includes(entity.id);
      mesh.showBoundingBox = isSelected;
      if (isSelected) {
        this.engineCore.highlightLayer.addMesh(mesh, new Color3(1, 0.62, 0.12));
      }
    });
  }
}
