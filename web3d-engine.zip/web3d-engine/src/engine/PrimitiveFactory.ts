import { Scene, MeshBuilder, Mesh } from '@babylonjs/core';
import { Entity, PrimitiveKind } from '../scene/Entity';
import { SceneGraph } from '../scene/SceneGraph';
import { MeshRendererComponent } from '../components/MeshRendererComponent';
import { CameraComponent } from '../components/CameraComponent';
import { LightComponent, LightKind } from '../components/LightComponent';

const counters: Record<string, number> = {};

function nextName(prefix: string): string {
  counters[prefix] = (counters[prefix] ?? 0) + 1;
  return `${prefix}_${counters[prefix]}`;
}

function buildPrimitiveMesh(scene: Scene, kind: PrimitiveKind, name: string): Mesh {
  switch (kind) {
    case 'cube':
      return MeshBuilder.CreateBox(name, { size: 1 }, scene);
    case 'sphere':
      return MeshBuilder.CreateSphere(name, { diameter: 1, segments: 16 }, scene);
    case 'plane':
      return MeshBuilder.CreateGround(name, { width: 2, height: 2 }, scene);
    case 'cylinder':
      return MeshBuilder.CreateCylinder(name, { diameter: 1, height: 1.5 }, scene);
    case 'capsule':
      return MeshBuilder.CreateCapsule(name, { radius: 0.5, height: 1.5 }, scene);
    case 'cone':
      return MeshBuilder.CreateCylinder(name, { diameterTop: 0, diameterBottom: 1, height: 1.5 }, scene);
    case 'torus':
      return MeshBuilder.CreateTorus(name, { diameter: 1, thickness: 0.3 }, scene);
    default:
      throw new Error(`Bilinmeyen primitive tipi: ${kind}`);
  }
}

export function createPrimitiveEntity(
  scene: Scene,
  graph: SceneGraph,
  kind: PrimitiveKind,
  parent: Entity | null = null
): Entity {
  const name = nextName(kind[0].toUpperCase() + kind.slice(1));
  const entity = new Entity(scene, name);
  const mesh = buildPrimitiveMesh(scene, kind, `${name}_mesh`);
  entity.components.meshRenderer = new MeshRendererComponent(scene, entity.node, mesh);
  graph.register(entity, parent);
  return entity;
}

export function createEmptyEntity(scene: Scene, graph: SceneGraph, parent: Entity | null = null): Entity {
  const name = nextName('Empty');
  const entity = new Entity(scene, name);
  graph.register(entity, parent);
  return entity;
}

export function createCameraEntity(scene: Scene, graph: SceneGraph, parent: Entity | null = null): Entity {
  const name = nextName('Camera');
  const entity = new Entity(scene, name);
  entity.components.camera = new CameraComponent(scene, entity.node, name);
  graph.register(entity, parent);
  return entity;
}

export function createLightEntity(
  scene: Scene,
  graph: SceneGraph,
  kind: LightKind,
  parent: Entity | null = null
): Entity {
  const prefix = kind === 'ambient' ? 'AmbientLight' : `${kind[0].toUpperCase() + kind.slice(1)}Light`;
  const name = nextName(prefix);
  const entity = new Entity(scene, name);
  entity.components.light = new LightComponent(scene, entity.node, kind, name);
  graph.register(entity, parent);
  return entity;
}
