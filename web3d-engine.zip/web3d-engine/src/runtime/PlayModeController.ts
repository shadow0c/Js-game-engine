import { Scene, Camera } from '@babylonjs/core';
import { SceneGraph } from '../scene/SceneGraph';
import { EditorStore } from '../state/EditorStore';

interface TransformSnapshot {
  entityId: string;
  position: [number, number, number];
  rotation: [number, number, number];
  scaling: [number, number, number];
}

/**
 * Play Mode, editör state'inden izole gerçek bir runtime döngüsü çalıştırır.
 * Play basıldığında tüm entity transformları anlık görüntülenir (snapshot);
 * Stop basıldığında bu görüntü birebir geri yüklenir. Sahnede bir Camera
 * component'i varsa Play sırasında aktif kamera olarak devreye girer.
 *
 * Not: Bu aşamada henüz Script/Physics runtime'ı bağlı değil (Aşama 2).
 * Play Mode altyapısı buraya hazır — scripting eklendiğinde update(dt)
 * çağrıları bu loop üzerinden akacak.
 */
export class PlayModeController {
  private snapshot: TransformSnapshot[] = [];
  private previousActiveCamera: Camera | null = null;
  private loopHandle: number | null = null;
  private lastTime = 0;
  playing = false;

  constructor(
    private scene: Scene,
    private graph: SceneGraph,
    private store: EditorStore,
    private editorCamera: Camera
  ) {}

  play(): void {
    if (this.playing) return;
    this.playing = true;

    this.snapshot = this.captureSnapshot();

    this.previousActiveCamera = this.scene.activeCamera;
    const playCamera = this.findFirstEntityCamera();
    if (playCamera) {
      this.scene.activeCamera = playCamera;
    }

    this.store.setPlaying(true);
    this.lastTime = performance.now();

    const loop = () => {
      const now = performance.now();
      const deltaTime = (now - this.lastTime) / 1000;
      this.lastTime = now;
      const elapsed = (this.store.runtimeInfo?.elapsed ?? 0) + deltaTime;
      this.store.setRuntimeInfo({ deltaTime, elapsed });
      if (this.playing) {
        this.loopHandle = requestAnimationFrame(loop);
      }
    };
    this.loopHandle = requestAnimationFrame(loop);
  }

  stop(): void {
    if (!this.playing) return;
    this.playing = false;
    if (this.loopHandle !== null) {
      cancelAnimationFrame(this.loopHandle);
      this.loopHandle = null;
    }

    this.snapshot.forEach((s) => {
      const entity = this.graph.entities.get(s.entityId);
      if (!entity) return;
      entity.transform.setPositionXYZ(s.position[0], s.position[1], s.position[2]);
      entity.transform.setRotationXYZ(s.rotation[0], s.rotation[1], s.rotation[2]);
      entity.transform.setScalingXYZ(s.scaling[0], s.scaling[1], s.scaling[2]);
    });

    this.scene.activeCamera = this.previousActiveCamera ?? this.editorCamera;
    this.store.setPlaying(false);
    this.store.setRuntimeInfo(null);
  }

  private captureSnapshot(): TransformSnapshot[] {
    const list: TransformSnapshot[] = [];
    this.graph.entities.forEach((entity) => {
      list.push({
        entityId: entity.id,
        position: entity.transform.position.asArray() as [number, number, number],
        rotation: entity.transform.rotation.asArray() as [number, number, number],
        scaling: entity.transform.scaling.asArray() as [number, number, number]
      });
    });
    return list;
  }

  private findFirstEntityCamera(): Camera | null {
    for (const entity of this.graph.entities.values()) {
      if (entity.components.camera) {
        return entity.components.camera.camera;
      }
    }
    return null;
  }
}
