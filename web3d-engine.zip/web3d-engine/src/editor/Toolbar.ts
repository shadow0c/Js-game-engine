import { Camera } from '@babylonjs/core';
import { SceneGraph } from '../scene/SceneGraph';
import { EditorStore } from '../state/EditorStore';
import { EngineCore } from '../engine/EngineCore';
import { GizmoController } from '../engine/GizmoController';
import { PlayModeController } from '../runtime/PlayModeController';
import { PrimitiveKind } from '../scene/Entity';
import { LightKind } from '../components/LightComponent';
import {
  createPrimitiveEntity,
  createEmptyEntity,
  createCameraEntity,
  createLightEntity
} from '../engine/PrimitiveFactory';

interface MenuItem {
  label: string;
  action: () => void;
}

export interface ToolbarCallbacks {
  onDeleteSelected: () => void;
  onFocusSelected: () => void;
}

export class Toolbar {
  private el: HTMLElement;

  constructor(
    container: HTMLElement,
    private engineCore: EngineCore,
    private graph: SceneGraph,
    private store: EditorStore,
    private playMode: PlayModeController,
    private gizmoController: GizmoController,
    private callbacks: ToolbarCallbacks
  ) {
    this.el = document.createElement('div');
    this.el.className = 'toolbar';
    container.appendChild(this.el);
    this.render();
  }

  private render(): void {
    this.el.innerHTML = '';

    this.el.appendChild(this.buildMenu('File', [{ label: 'New Scene', action: () => this.newScene() }]));

    this.el.appendChild(
      this.buildMenu('Create', [
        { label: 'Empty Entity', action: () => this.createEmpty() },
        { label: 'Cube', action: () => this.createPrimitive('cube') },
        { label: 'Sphere', action: () => this.createPrimitive('sphere') },
        { label: 'Plane', action: () => this.createPrimitive('plane') },
        { label: 'Cylinder', action: () => this.createPrimitive('cylinder') },
        { label: 'Capsule', action: () => this.createPrimitive('capsule') },
        { label: 'Cone', action: () => this.createPrimitive('cone') },
        { label: 'Torus', action: () => this.createPrimitive('torus') },
        { label: 'Directional Light', action: () => this.createLight('directional') },
        { label: 'Point Light', action: () => this.createLight('point') },
        { label: 'Spot Light', action: () => this.createLight('spot') },
        { label: 'Ambient Light', action: () => this.createLight('ambient') },
        { label: 'Camera', action: () => this.createCamera() }
      ])
    );

    this.el.appendChild(
      this.buildMenu('GameObject', [
        { label: 'Delete Selected (Del)', action: () => this.callbacks.onDeleteSelected() },
        { label: 'Focus Selected (F)', action: () => this.callbacks.onFocusSelected() }
      ])
    );

    const spacer = document.createElement('div');
    spacer.className = 'toolbar-spacer';
    this.el.appendChild(spacer);

    this.el.appendChild(this.buildWireframeToggle());
    this.el.appendChild(this.buildSnapControls());
    this.el.appendChild(this.buildProjectionToggle());
    this.el.appendChild(this.buildPlayControls());
  }

  private buildMenu(label: string, items: MenuItem[]): HTMLElement {
    const wrap = document.createElement('div');
    wrap.className = 'toolbar-menu';

    const button = document.createElement('button');
    button.className = 'toolbar-menu-button';
    button.textContent = label;

    const list = document.createElement('div');
    list.className = 'toolbar-menu-list';
    list.style.display = 'none';

    items.forEach((item) => {
      const entry = document.createElement('div');
      entry.className = 'toolbar-menu-item';
      entry.textContent = item.label;
      entry.addEventListener('click', () => {
        item.action();
        list.style.display = 'none';
      });
      list.appendChild(entry);
    });

    button.addEventListener('click', (e) => {
      e.stopPropagation();
      const isOpen = list.style.display !== 'none';
      document.querySelectorAll('.toolbar-menu-list').forEach((l) => {
        (l as HTMLElement).style.display = 'none';
      });
      list.style.display = isOpen ? 'none' : 'block';
    });

    document.addEventListener('click', () => {
      list.style.display = 'none';
    });

    wrap.appendChild(button);
    wrap.appendChild(list);
    return wrap;
  }

  private createPrimitive(kind: PrimitiveKind): void {
    const entity = createPrimitiveEntity(this.engineCore.scene, this.graph, kind);
    this.store.setSelection([entity.id]);
    this.store.log('info', `${entity.name} sahneye eklendi`);
  }

  private createEmpty(): void {
    const entity = createEmptyEntity(this.engineCore.scene, this.graph);
    this.store.setSelection([entity.id]);
    this.store.log('info', `${entity.name} sahneye eklendi`);
  }

  private createCamera(): void {
    const entity = createCameraEntity(this.engineCore.scene, this.graph);
    this.store.setSelection([entity.id]);
    this.store.log('info', `${entity.name} sahneye eklendi`);
  }

  private createLight(kind: LightKind): void {
    const entity = createLightEntity(this.engineCore.scene, this.graph, kind);
    this.store.setSelection([entity.id]);
    this.store.log('info', `${entity.name} sahneye eklendi`);
  }

  private newScene(): void {
    [...this.graph.entities.keys()].forEach((id) => this.graph.remove(id));
    this.store.setSelection([]);
    this.store.log('info', 'Yeni sahne oluşturuldu');
  }

  private buildWireframeToggle(): HTMLElement {
    const label = document.createElement('label');
    label.className = 'toolbar-toggle';
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.addEventListener('change', () => {
      this.engineCore.scene.forceWireframe = input.checked;
      this.store.setWireframe(input.checked);
    });
    label.appendChild(input);
    label.appendChild(document.createTextNode('Wireframe'));
    return label;
  }

  private buildSnapControls(): HTMLElement {
    const wrap = document.createElement('div');
    wrap.className = 'toolbar-snap';

    const label = document.createElement('label');
    label.className = 'toolbar-toggle';
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.addEventListener('change', () => this.gizmoController.setSnapEnabled(input.checked));
    label.appendChild(input);
    label.appendChild(document.createTextNode('Snap'));

    const sizeInput = document.createElement('input');
    sizeInput.type = 'number';
    sizeInput.className = 'toolbar-snap-size';
    sizeInput.value = '1';
    sizeInput.step = '0.1';
    sizeInput.min = '0.1';
    sizeInput.addEventListener('change', () => {
      this.gizmoController.setSnapSize(parseFloat(sizeInput.value) || 1);
    });

    wrap.appendChild(label);
    wrap.appendChild(sizeInput);
    return wrap;
  }

  private buildProjectionToggle(): HTMLElement {
    const button = document.createElement('button');
    button.className = 'toolbar-button';
    button.textContent = 'Perspective';
    let ortho = false;

    button.addEventListener('click', () => {
      ortho = !ortho;
      const cam = this.engineCore.editorCamera;
      if (ortho) {
        const aspect = this.engineCore.engine.getRenderWidth() / this.engineCore.engine.getRenderHeight();
        const size = cam.radius * 0.5;
        cam.orthoLeft = -size * aspect;
        cam.orthoRight = size * aspect;
        cam.orthoTop = size;
        cam.orthoBottom = -size;
        cam.mode = Camera.ORTHOGRAPHIC_CAMERA;
        button.textContent = 'Orthographic';
      } else {
        cam.mode = Camera.PERSPECTIVE_CAMERA;
        button.textContent = 'Perspective';
      }
    });

    return button;
  }

  private buildPlayControls(): HTMLElement {
    const wrap = document.createElement('div');
    wrap.className = 'toolbar-play-controls';

    const playButton = document.createElement('button');
    playButton.className = 'toolbar-play-button';
    playButton.textContent = '▶ Play';

    const stopButton = document.createElement('button');
    stopButton.className = 'toolbar-stop-button';
    stopButton.textContent = '■ Stop';
    stopButton.disabled = true;

    playButton.addEventListener('click', () => {
      this.playMode.play();
      playButton.disabled = true;
      stopButton.disabled = false;
      this.store.log('info', 'Play Mode başlatıldı');
    });

    stopButton.addEventListener('click', () => {
      this.playMode.stop();
      playButton.disabled = false;
      stopButton.disabled = true;
      this.store.log('info', 'Play Mode durduruldu');
    });

    wrap.appendChild(playButton);
    wrap.appendChild(stopButton);
    return wrap;
  }
}
