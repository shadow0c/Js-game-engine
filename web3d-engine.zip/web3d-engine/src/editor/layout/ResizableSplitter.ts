export function makeHorizontallyResizable(
  target: HTMLElement,
  handle: HTMLElement,
  growDirection: 'left' | 'right'
): void {
  let startX = 0;
  let startWidth = 0;

  const onMouseMove = (event: MouseEvent) => {
    const delta = growDirection === 'right' ? event.clientX - startX : startX - event.clientX;
    const newWidth = Math.max(160, Math.min(560, startWidth + delta));
    target.style.flex = `0 0 ${newWidth}px`;
  };

  const onMouseUp = () => {
    window.removeEventListener('mousemove', onMouseMove);
    window.removeEventListener('mouseup', onMouseUp);
  };

  handle.addEventListener('mousedown', (event) => {
    startX = event.clientX;
    startWidth = target.getBoundingClientRect().width;
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    event.preventDefault();
  });
}
