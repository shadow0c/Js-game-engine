import { EditorStore, LogEntry } from '../../state/EditorStore';

export class ConsolePanel {
  private el: HTMLElement;
  private listEl: HTMLElement;

  constructor(container: HTMLElement, private store: EditorStore) {
    this.el = document.createElement('div');
    this.el.className = 'panel console-panel';
    this.el.innerHTML = `
      <div class="panel-header">Console</div>
      <div class="console-list"></div>
    `;
    container.appendChild(this.el);
    this.listEl = this.el.querySelector('.console-list')!;

    this.store.on('logAdded', (entry) => this.appendEntry(entry));
    this.hookGlobalConsole();
  }

  private hookGlobalConsole(): void {
    (['log', 'info', 'warn', 'error'] as const).forEach((level) => {
      const original = console[level].bind(console);
      console[level] = (...args: unknown[]) => {
        original(...args);
        const message = args.map((a) => (typeof a === 'string' ? a : safeStringify(a))).join(' ');
        this.store.log(level, message);
      };
    });
  }

  private appendEntry(entry: LogEntry): void {
    const row = document.createElement('div');
    row.className = `console-row console-${entry.level}`;
    const time = new Date(entry.timestamp).toLocaleTimeString();
    row.textContent = `[${time}] ${entry.message}`;
    this.listEl.appendChild(row);
    this.listEl.scrollTop = this.listEl.scrollHeight;
  }
}

function safeStringify(value: unknown): string {
  try {
    return JSON.stringify(value);
  } catch {
    return String(value);
  }
}
