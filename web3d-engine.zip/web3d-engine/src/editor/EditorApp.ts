import { EngineCore } from '../engine/EngineCore';
import { SceneGraph } from '../scene/SceneGraph';
import { EditorStore } from '../state/EditorStore';
import { GizmoController } from '../engine/GizmoController';
import { SelectionManager } from '../engine/SelectionManager';
import { PlayModeController } from '../runtime/PlayModeController';
import { Toolbar } from './Toolbar';
import { Viewport } from './viewport/Viewport';
import { HierarchyPanel } from './hierarchy/HierarchyPanel';
import { InspectorPanel } from './inspector/InspectorPanel';
import { ConsolePanel } from './console/ConsolePanel';
import { makeHorizontallyResizable } from './layout/ResizableSplitter';
import { createPrimitiveEntity, createLightEntity } from '../engine/PrimitiveFactory';

export class EditorApp {
  private engineCore: EngineCore;
  private graph: SceneGraph;
  private store = new EditorStore();
  private gizmoController: GizmoController;

  constructor(private root: HTMLElement) {
    root.innerHTML = `
      <div class="editor-shell">
        <div class="toolbar-row"></div>
        <div class="main-row">
          <div class="hierarchy-col"></div>
          <div class="col-resizer" data-resizer="hierarchy"></div>
          <div class="viewport-col"></div>
          <div class="col-resizer" data-resizer="inspector"></div>
          <div class="inspector-col"></div>
        </div>
        <div class="asset-row">
          <div class="panel asset-placeholder-panel">
            <div class="panel-header">Asset Browser</div>
            <div class="asset-placeholder-note">
              Asset Browser bu aşamada henüz eklenmedi — gerçek dosya import / drag&amp;drop / IndexedDB
              sistemi bir sonraki aşamada (Aşama 2) implement edilecek.
            </div>
          </div>
        </div>
        <div class="console-row"></div>
      </div>
    `;

    const viewportCol = root.querySelector('.viewport-col') as HTMLElement;
    const canvas = document.createElement('canvas');
    canvas.className = 'engine-canvas';
    canvas.tabIndex = 0;
    viewportCol.appendChild(canvas);

    this.engineCore = new EngineCore(canvas);
    this.graph = new SceneGraph(this.engineCore.scene);
    this.gizmoController = new GizmoController(this.engineCore.scene, this.graph, this.store);
    new SelectionManager(this.engineCore, this.graph, this.store);
    const playMode = new PlayModeController(
      this.engineCore.scene,
      this.graph,
      this.store,
      this.engineCore.editorCamera
    );

    new ConsolePanel(root.querySelector('.console-row') as HTMLElement, this.store);
    new HierarchyPanel(root.querySelector('.hierarchy-col') as HTMLElement, this.graph, this.store, (id) =>
      this.deleteEntity(id)
    );
    new InspectorPanel(root.querySelector('.inspector-col') as HTMLElement, this.graph, this.store);

    const callbacks = {
      onDeleteSelected: () => this.deleteSelected(),
      onFocusSelected: () => this.focusSelected()
    };

    new Toolbar(
      root.querySelector('.toolbar-row') as HTMLElement,
      this.engineCore,
      this.graph,
      this.store,
      playMode,
      this.gizmoController,
      callbacks
    );

    new Viewport(viewportCol, this.engineCore, this.graph, this.store, this.gizmoController, callbacks);

    const hierarchyResizer = root.querySelector('[data-resizer="hierarchy"]') as HTMLElement;
    const inspectorResizer = root.querySelector('[data-resizer="inspector"]') as HTMLElement;
    makeHorizontallyResizable(root.querySelector('.hierarchy-col') as HTMLElement, hierarchyResizer, 'right');
    makeHorizontallyResizable(root.querySelector('.inspector-col') as HTMLElement, inspectorResizer, 'left');

    this.engineCore.start();
    this.seedDefaultScene();
    this.store.log('info', 'Engine başlatıldı — WebGL2 render pipeline aktif');
  }

  private seedDefaultScene(): void {
    const cube = createPrimitiveEntity(this.engineCore.scene, this.graph, 'cube');
    cube.transform.setPositionXYZ(0, 0.5, 0);

    const light = createLightEntity(this.engineCore.scene, this.graph, 'directional');
    light.transform.setRotationXYZ(Math.PI / 3, Math.PI / 4, 0);

    this.store.setSelection([cube.id]);
  }

  private deleteSelected(): void {
    [...this.store.selectedIds].forEach((id) => this.deleteEntity(id));
  }

  private deleteEntity(id: string): void {
    const entity = this.graph.entities.get(id);
    if (!entity) return;
    this.store.log('info', `${entity.name} silindi`);
    this.graph.remove(id);
    this.store.setSelection(this.store.selectedIds.filter((sid) => sid !== id));
  }

  private focusSelected(): void {
    const [id] = this.store.selectedIds;
    const entity = id ? this.graph.entities.get(id) : undefined;
    if (!entity) return;
    entity.node.computeWorldMatrix(true);
    const pos = entity.node.getAbsolutePosition();
    this.engineCore.editorCamera.target.copyFrom(pos);
    this.engineCore.editorCamera.radius = 6;
  }
}
