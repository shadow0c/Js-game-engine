import { EngineCore } from '../../engine/EngineCore';
import { SceneGraph } from '../../scene/SceneGraph';
import { EditorStore } from '../../state/EditorStore';
import { GizmoController, GizmoMode } from '../../engine/GizmoController';
import { isTypingTarget } from '../../core/dom';

export interface ViewportCallbacks {
  onDeleteSelected: () => void;
  onFocusSelected: () => void;
}

export class Viewport {
  private statsEl: HTMLElement;

  constructor(
    private host: HTMLElement,
    private engineCore: EngineCore,
    private graph: SceneGraph,
    private store: EditorStore,
    private gizmoController: GizmoController,
    private callbacks: ViewportCallbacks
  ) {
    this.host.classList.add('viewport-panel');

    const overlay = document.createElement('div');
    overlay.className = 'viewport-overlay';
    overlay.innerHTML = `
      <span class="viewport-mode-label">TRANSLATE</span>
      <span class="viewport-play-indicator">PLAY MODE</span>
    `;
    this.host.appendChild(overlay);
    const playIndicator = overlay.querySelector('.viewport-play-indicator') as HTMLElement;
    playIndicator.style.display = 'none';

    this.statsEl = document.createElement('div');
    this.statsEl.className = 'viewport-stats';
    this.host.appendChild(this.statsEl);

    this.store.on('playingChanged', (playing) => {
      playIndicator.style.display = playing ? 'inline-block' : 'none';
    });
    this.store.on('gizmoModeChanged', (mode) => {
      (overlay.querySelector('.viewport-mode-label') as HTMLElement).textContent = mode.toUpperCase();
    });

    this.engineCore.scene.onAfterRenderObservable.add(() => {
      this.statsEl.textContent = `FPS: ${this.engineCore.engine.getFps().toFixed(0)}  |  Entities: ${this.graph.entities.size}`;
    });

    this.bindShortcuts();
  }

  private bindShortcuts(): void {
    window.addEventListener('keydown', (e) => {
      if (isTypingTarget(e.target)) return;
      if (this.engineCore.isFlying) return;

      switch (e.key.toLowerCase()) {
        case 'q':
          this.setMode('select');
          break;
        case 'w':
          this.setMode('translate');
          break;
        case 'e':
          this.setMode('rotate');
          break;
        case 'r':
          this.setMode('scale');
          break;
        case 'f':
          this.callbacks.onFocusSelected();
          break;
        case 'delete':
        case 'backspace':
          if (this.store.selectedIds.length > 0) {
            e.preventDefault();
            this.callbacks.onDeleteSelected();
          }
          break;
      }
    });
  }

  private setMode(mode: GizmoMode): void {
    this.gizmoController.setMode(mode);
    this.store.setGizmoMode(mode);
  }
}
