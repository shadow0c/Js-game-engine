import { SceneGraph } from '../../scene/SceneGraph';
import { EditorStore } from '../../state/EditorStore';
import { Entity } from '../../scene/Entity';

export class HierarchyPanel {
  private el: HTMLElement;
  private treeEl: HTMLElement;

  constructor(
    container: HTMLElement,
    private graph: SceneGraph,
    private store: EditorStore,
    private onDeleteRequest: (id: string) => void
  ) {
    this.el = document.createElement('div');
    this.el.className = 'panel hierarchy-panel';
    this.el.innerHTML = `<div class="panel-header">Hierarchy</div><div class="hierarchy-tree"></div>`;
    container.appendChild(this.el);
    this.treeEl = this.el.querySelector('.hierarchy-tree')!;

    this.graph.on('hierarchyChanged', () => this.render());
    this.store.on('selectionChanged', () => this.render());
    this.render();
  }

  private render(): void {
    this.treeEl.innerHTML = '';
    this.graph.roots.forEach((entity) => this.renderEntity(entity, this.treeEl, 0));
  }

  private renderEntity(entity: Entity, parentEl: HTMLElement, depth: number): void {
    const row = document.createElement('div');
    row.className = 'hierarchy-row';
    row.style.paddingLeft = `${depth * 14 + 8}px`;
    if (this.store.selectedIds.includes(entity.id)) row.classList.add('selected');
    row.textContent = entity.name;

    row.addEventListener('click', (e) => {
      if ((e as MouseEvent).shiftKey) {
        this.store.toggleSelection(entity.id);
      } else {
        this.store.setSelection([entity.id]);
      }
    });

    row.addEventListener('dblclick', () => this.startRename(row, entity));

    row.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      this.showContextMenu(e as MouseEvent, entity);
    });

    parentEl.appendChild(row);
    entity.children.forEach((child) => this.renderEntity(child, parentEl, depth + 1));
  }

  private startRename(row: HTMLElement, entity: Entity): void {
    const input = document.createElement('input');
    input.className = 'hierarchy-rename-input';
    input.value = entity.name;
    row.textContent = '';
    row.appendChild(input);
    input.focus();
    input.select();

    const commit = () => {
      const value = input.value.trim();
      if (value) this.graph.rename(entity.id, value);
      else this.render();
    };
    input.addEventListener('blur', commit);
    input.addEventListener('keydown', (ev) => {
      if (ev.key === 'Enter') input.blur();
      if (ev.key === 'Escape') {
        input.value = entity.name;
        input.blur();
      }
    });
  }

  private showContextMenu(e: MouseEvent, entity: Entity): void {
    document.querySelector('.context-menu')?.remove();

    const menu = document.createElement('div');
    menu.className = 'context-menu';
    menu.style.left = `${e.clientX}px`;
    menu.style.top = `${e.clientY}px`;

    const deleteItem = document.createElement('div');
    deleteItem.className = 'context-menu-item';
    deleteItem.textContent = 'Delete';
    deleteItem.addEventListener('click', () => {
      this.onDeleteRequest(entity.id);
      menu.remove();
    });
    menu.appendChild(deleteItem);
    document.body.appendChild(menu);

    const closeMenu = (ev: MouseEvent) => {
      if (!menu.contains(ev.target as Node)) {
        menu.remove();
        document.removeEventListener('click', closeMenu);
      }
    };
    setTimeout(() => document.addEventListener('click', closeMenu), 0);
  }
}
