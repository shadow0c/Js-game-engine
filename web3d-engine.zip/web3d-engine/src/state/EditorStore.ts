import { EventEmitter } from '../core/EventEmitter';
import type { GizmoMode } from '../engine/GizmoController';

export interface RuntimeInfo {
  deltaTime: number;
  elapsed: number;
}

export interface LogEntry {
  level: 'log' | 'info' | 'warn' | 'error';
  message: string;
  timestamp: number;
}

export interface StoreEvents {
  selectionChanged: string[];
  playingChanged: boolean;
  runtimeInfoChanged: RuntimeInfo | null;
  gizmoModeChanged: GizmoMode;
  wireframeChanged: boolean;
  logAdded: LogEntry;
}

export class EditorStore extends EventEmitter<StoreEvents> {
  selectedIds: string[] = [];
  playing = false;
  runtimeInfo: RuntimeInfo | null = null;
  gizmoMode: GizmoMode = 'translate';
  wireframe = false;
  logs: LogEntry[] = [];

  setSelection(ids: string[]): void {
    this.selectedIds = ids;
    this.emit('selectionChanged', ids);
  }

  toggleSelection(id: string): void {
    this.selectedIds = this.selectedIds.includes(id)
      ? this.selectedIds.filter((x) => x !== id)
      : [...this.selectedIds, id];
    this.emit('selectionChanged', this.selectedIds);
  }

  setPlaying(playing: boolean): void {
    this.playing = playing;
    this.emit('playingChanged', playing);
  }

  setRuntimeInfo(info: RuntimeInfo | null): void {
    this.runtimeInfo = info;
    this.emit('runtimeInfoChanged', info);
  }

  setGizmoMode(mode: GizmoMode): void {
    this.gizmoMode = mode;
    this.emit('gizmoModeChanged', mode);
  }

  setWireframe(enabled: boolean): void {
    this.wireframe = enabled;
    this.emit('wireframeChanged', enabled);
  }

  log(level: LogEntry['level'], message: string): void {
    const entry: LogEntry = { level, message, timestamp: Date.now() };
    this.logs.push(entry);
    if (this.logs.length > 500) this.logs.shift();
    this.emit('logAdded', entry);
  }
}
