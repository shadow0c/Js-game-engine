import { Scene } from '@babylonjs/core';
import { Entity } from './Entity';
import { EventEmitter } from '../core/EventEmitter';

export interface SceneGraphEvents {
  entityAdded: Entity;
  entityRemoved: string;
  hierarchyChanged: void;
}

export class SceneGraph extends EventEmitter<SceneGraphEvents> {
  readonly entities = new Map<string, Entity>();
  readonly roots: Entity[] = [];

  constructor(public scene: Scene) {
    super();
  }

  register(entity: Entity, parent: Entity | null = null): void {
    this.entities.set(entity.id, entity);
    if (parent) {
      entity.setParent(parent);
    } else {
      this.roots.push(entity);
    }
    this.emit('entityAdded', entity);
    this.emit('hierarchyChanged', undefined);
  }

  remove(entityId: string): void {
    const entity = this.entities.get(entityId);
    if (!entity) return;

    [...entity.children].forEach((child) => this.remove(child.id));

    if (entity.parent) {
      const idx = entity.parent.children.indexOf(entity);
      if (idx >= 0) entity.parent.children.splice(idx, 1);
    } else {
      const idx = this.roots.indexOf(entity);
      if (idx >= 0) this.roots.splice(idx, 1);
    }

    entity.dispose();
    this.entities.delete(entityId);
    this.emit('entityRemoved', entityId);
    this.emit('hierarchyChanged', undefined);
  }

  rename(entityId: string, name: string): void {
    const entity = this.entities.get(entityId);
    if (!entity) return;
    entity.name = name;
    entity.node.name = name;
    this.emit('hierarchyChanged', undefined);
  }
}
