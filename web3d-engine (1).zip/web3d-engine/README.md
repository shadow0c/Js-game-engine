# Web3D Engine — Aşama 1 (MVP Çekirdek)

Tarayıcıda gerçekten çalışan, WebGL2 tabanlı, TypeScript ile yazılmış bir mini
3D game engine / editör. Render pipeline ve scene graph için Babylon.js
(@babylonjs/core) kullanılır — ama sahne, entity, component, seçim, gizmo,
undo-uyumlu play/stop döngüsü gibi tüm **editör mantığı kendi kodumuzdadır**.
Babylon burada sadece GPU'ya çizim yapan gerçek bir render motoru olarak
kullanılıyor; hiçbir buton veya panel sahte/mockup değildir.

## Çalıştırma

```bash
npm install
npm run dev       # http://localhost:5173
```

Production build:

```bash
npm run build      # tsc ile tip kontrolü + vite build
npm run preview
```

> Bu kod bir sandbox'ta (internet erişimi olmayan bir container) yazıldı;
> `npm install` bu ortamda çalıştırılıp doğrulanamadı. Kodun tamamı
> Babylon.js v7 API'sine göre dikkatlice yazıldı, ancak ilk `npm run dev`
> sonrası bir TypeScript/derleme hatası çıkarsa (paket sürüm uyuşmazlığı vb.)
> hatayı bana yapıştırman yeterli — hemen düzeltirim.

## Güncelleme notu

Geri bildirimin üzerine iki gerçek bug bulundu ve düzeltildi:

1. **Kritik CSS bug**: `.viewport-panel` sınıfı `.viewport-col`'un zaten sahip
   olduğu `position: relative`'i `position: absolute; inset: 0` ile eziyordu.
   Bu, 3D viewport'un flexbox akışından tamamen kopup **tüm sayfayı
   kaplamasına** sebep oluyordu — Inspector, Hierarchy, Toolbar, Console hepsi
   bu yüzden görünmüyordu. Düzeltildi (`src/style.css`).
2. **Eksik özellik**: Orijinal istekteki "360 derece döndürebilme (Oklar)"
   maddesi Aşama 1'de unutulmuştu — ok tuşlarıyla kamera orbit kontrolü artık
   gerçekten bağlı (`EngineCore.enableArrowKeyOrbit`).

Ayrıca **Asset Browser artık gerçek** (aşağıda detaylı).

## Şu an gerçekten çalışan özellikler (Aşama 1)

- Gerçek WebGL2 render pipeline + render loop (`EngineCore`)
- Gerçek scene graph: her `Entity` bir Babylon `TransformNode`'a sahiptir,
  parent/child ilişkisi gerçek node parenting ile kurulur
- Component sistemi: `Transform`, `MeshRenderer`, `Camera`, `Light`
  (Directional/Point/Spot/Ambient)
- Create menüsünden 7 primitive (Cube, Sphere, Plane, Cylinder, Capsule,
  Cone, Torus) + Empty Entity + Camera + 4 ışık tipi — hepsi gerçekten
  sahneye ekleniyor
- Gerçek raycasting ile obje seçimi (tekli + Shift ile çoklu), bounding box,
  highlight
- Gerçek Position/Rotation/Scale gizmo'ları (Babylon `UtilityLayerRenderer`
  tabanlı), grid snapping
- Hierarchy paneli gerçek scene graph ile birebir bağlı (seçim, çift tık
  rename, sağ tık Delete context menu)
- Inspector paneli seçili entity'nin component'lerine göre **dinamik**
  oluşur; her alan değişikliği anında sahneye yansır (ve tam tersi — gizmo
  ile sürüklediğinde Inspector anında güncellenir)
- Play Mode: basılınca tüm transform'ların anlık görüntüsü alınır, izole bir
  `requestAnimationFrame` döngüsü başlar, sahnede Camera component'i varsa
  aktif kamera olur; Stop'a basınca transformlar birebir geri yüklenir
- Console paneli: `console.log/info/warn/error` gerçekten hook'lanır,
  runtime hataları (`window.onerror`) burada görünür
- WASD + sağ-tık ile kamera fly, sol-drag orbit, tekerlek zoom, sağ-drag pan
  (Babylon `ArcRotateCamera`), Perspective/Orthographic geçişi
  Wireframe/Shaded geçişi
- Kısayollar: `Q` Select, `W` Translate, `E` Rotate, `R` Scale, `F` Focus,
  `Delete` sil
- Panel genişlikleri gerçek sürükle-bırak ile yeniden boyutlandırılabilir
- Ok tuşları (Sol/Sağ/Yukarı/Aşağı) basılı tutularak kameranın hedef etrafında
  tam 360° yatay/dikey orbit yapması

### Asset Browser (yeni)

- **Import**: dosya seçici (+ Import butonu) veya işletim sisteminden panele
  gerçek OS drag&drop
- Desteklenen tipler: `.glb` `.gltf` (model), `.png` `.jpg` `.jpeg` `.webp`
  (texture), `.hdr` (environment)
- **Gerçek IndexedDB kalıcılığı** — dosyaların kendisi tarayıcıda saklanır,
  sayfa yenilense/tarayıcı kapansa bile asset kütüphanesi kaybolmaz
- Texture'lar gerçek thumbnail ile önizlenir
- Asset kartı **viewport'a sürüklenip bırakılabilir**:
  - Model → `SceneLoader.ImportMeshAsync` ile gerçekten sahneye import edilir,
    bırakılan noktaya yerleştirilir, Hierarchy'de yeni bir Entity olarak
    görünür (Inspector'da "Imported Model" bölümü ile)
  - Texture → bırakılan mesh'in gerçek material'ına (`diffuseTexture`) uygulanır
  - `.hdr` → sahnenin gerçek `environmentTexture`'ı olarak ayarlanır
- Sağ tık → Delete ile asset kütüphaneden silinir (IndexedDB'den de)

> Bu özellik `@babylonjs/loaders` paketine ihtiyaç duyar — `npm install`
> sırasında otomatik kurulacak. GLTF import kodu Babylon.js v7 API'sine göre
> dikkatle yazıldı ama sandbox'ta gerçek bir `.glb` dosyasıyla test edilemedi;
> ilk denemede bir hata çıkarsa hatayı yapıştırman yeterli.

## Aşama 3'te eklenecekler (henüz yok — sahte göstermiyoruz)

1. **Physics** — Rapier entegrasyonu (Rigidbody, Box/Sphere/Capsule Collider,
   gravity, collision/trigger)
2. **Materials** — Tam PBR material sistemi (metallic/roughness/emissive/
   normal map paneli — şu an sadece base color + wireframe var)
3. **Scripting** — `class X extends Script { awake/start/update/destroy }`
   lifecycle, Input API (keyboard/mouse/pointer), Play Mode loop'una bağlanma
4. **Serialization** — Scene JSON formatı, Save/Load/Duplicate/Rename/New
   Scene, IndexedDB persistence
5. **Undo/Redo** — Command pattern tabanlı gerçek history sistemi (object
   creation/deletion, transform, rename, component ekleme/silme)

Bu aşamalar mevcut mimariye (SceneGraph / EditorStore / component sistemi)
oturacak şekilde tasarlandı — örn. `PlayModeController` şimdiden script
`update(dt)` çağrılarını bağlayabileceğimiz izole bir loop çalıştırıyor.

## Mimari

```
src/
├── core/            EventEmitter, id üretici, dom yardımcıları
├── scene/            Entity, SceneGraph (gerçek scene graph)
├── components/       Transform, MeshRenderer, Camera, Light
├── engine/           EngineCore (renderer), PrimitiveFactory,
│                     SelectionManager, GizmoController
├── state/            EditorStore (reaktif merkezi state)
├── runtime/          PlayModeController (izole play/stop döngüsü)
├── editor/
│   ├── viewport/      Viewport (kısayollar, stats overlay)
│   ├── hierarchy/      HierarchyPanel
│   ├── inspector/      InspectorPanel
│   ├── console/        ConsolePanel
│   └── layout/         ResizableSplitter
└── main.ts           Bootstrap + WebGL2 kontrolü + global hata yakalama
```

Editor state (`EditorStore`) ile sahne durumu (`SceneGraph`) ayrıdır; tüm
paneller bunlara abone olur ve değişiklikler tek yönlü, gerçek event'ler
üzerinden yayılır (mockup binding yok).
