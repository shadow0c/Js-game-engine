import { createId } from '../core/id';
import { AssetKind } from './AssetTypes';

const DB_NAME = 'web3d-engine-assets';
const STORE_NAME = 'assets';
const DB_VERSION = 1;

export interface StoredAssetRecord {
  id: string;
  name: string;
  type: AssetKind;
  mimeType: string;
  size: number;
  blob: Blob;
  createdAt: number;
}

/**
 * Gerçek tarayıcı IndexedDB'sine dayanan asset kütüphanesi.
 * Dosyaların kendisi (Blob/File) doğrudan saklanır — sayfa yenilense
 * veya tarayıcı kapatılıp açılsa bile asset'ler kaybolmaz.
 */
export class AssetDatabase {
  private dbPromise: Promise<IDBDatabase>;

  constructor() {
    this.dbPromise = this.openDb();
  }

  private openDb(): Promise<IDBDatabase> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          db.createObjectStore(STORE_NAME, { keyPath: 'id' });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  async addAsset(file: File, kind: AssetKind): Promise<StoredAssetRecord> {
    const db = await this.dbPromise;
    const record: StoredAssetRecord = {
      id: createId('asset'),
      name: file.name,
      type: kind,
      mimeType: file.type,
      size: file.size,
      blob: file,
      createdAt: Date.now()
    };
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).put(record);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    return record;
  }

  async listAssets(): Promise<StoredAssetRecord[]> {
    const db = await this.dbPromise;
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const req = tx.objectStore(STORE_NAME).getAll();
      req.onsuccess = () => resolve(req.result as StoredAssetRecord[]);
      req.onerror = () => reject(req.error);
    });
  }

  async deleteAsset(id: string): Promise<void> {
    const db = await this.dbPromise;
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
}
