export type AssetKind = 'model' | 'texture' | 'environment' | 'other';

const MODEL_EXTENSIONS = ['.glb', '.gltf'];
const TEXTURE_EXTENSIONS = ['.png', '.jpg', '.jpeg', '.webp'];
const ENVIRONMENT_EXTENSIONS = ['.hdr'];

export function detectAssetKind(filename: string): AssetKind | null {
  const lower = filename.toLowerCase();
  if (MODEL_EXTENSIONS.some((ext) => lower.endsWith(ext))) return 'model';
  if (TEXTURE_EXTENSIONS.some((ext) => lower.endsWith(ext))) return 'texture';
  if (ENVIRONMENT_EXTENSIONS.some((ext) => lower.endsWith(ext))) return 'environment';
  return null;
}
