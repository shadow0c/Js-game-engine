import { AbstractMesh, TransformNode } from '@babylonjs/core';

/**
 * GLTF/GLB import sonucu gelen mesh listesini entity'nin node'una bağlar.
 * Modelin kendi iç hiyerarşisi korunur — sadece kök mesh'ler (parent'ı
 * olmayanlar) entity node'una parent'lanır.
 */
export class ImportedModelComponent {
  readonly meshes: AbstractMesh[];

  constructor(public readonly sourceName: string, meshes: AbstractMesh[], node: TransformNode) {
    this.meshes = meshes;
    meshes.forEach((mesh) => {
      if (!mesh.parent) mesh.parent = node;
    });
  }

  dispose(): void {
    this.meshes.forEach((mesh) => mesh.dispose());
  }
}
