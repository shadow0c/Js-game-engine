import { EngineCore } from '../engine/EngineCore';
import { SceneGraph } from '../scene/SceneGraph';
import { EditorStore } from '../state/EditorStore';
import { GizmoController } from '../engine/GizmoController';
import { SelectionManager } from '../engine/SelectionManager';
import { PlayModeController } from '../runtime/PlayModeController';
import { Toolbar } from './Toolbar';
import { Viewport } from './viewport/Viewport';
import { HierarchyPanel } from './hierarchy/HierarchyPanel';
import { InspectorPanel } from './inspector/InspectorPanel';
import { ConsolePanel } from './console/ConsolePanel';
import { AssetBrowserPanel } from './assets/AssetBrowserPanel';
import { makeHorizontallyResizable } from './layout/ResizableSplitter';
import { createPrimitiveEntity, createLightEntity } from '../engine/PrimitiveFactory';
import { AssetDatabase } from '../assets/AssetDatabase';
import { importModelAsset, applyTextureToEntity, applyEnvironment } from '../engine/AssetImportService';

export class EditorApp {
  private engineCore: EngineCore;
  private graph: SceneGraph;
  private store = new EditorStore();
  private gizmoController: GizmoController;
  private assetDb = new AssetDatabase();

  constructor(private root: HTMLElement) {
    root.innerHTML = `
      <div class="editor-shell">
        <div class="toolbar-row"></div>
        <div class="main-row">
          <div class="hierarchy-col"></div>
          <div class="col-resizer" data-resizer="hierarchy"></div>
          <div class="viewport-col"></div>
          <div class="col-resizer" data-resizer="inspector"></div>
          <div class="inspector-col"></div>
        </div>
        <div class="asset-row"></div>
        <div class="console-row"></div>
      </div>
    `;

    const viewportCol = root.querySelector('.viewport-col') as HTMLElement;
    const canvas = document.createElement('canvas');
    canvas.className = 'engine-canvas';
    canvas.tabIndex = 0;
    viewportCol.appendChild(canvas);

    this.engineCore = new EngineCore(canvas);
    this.graph = new SceneGraph(this.engineCore.scene);
    this.gizmoController = new GizmoController(this.engineCore.scene, this.graph, this.store);
    new SelectionManager(this.engineCore, this.graph, this.store);
    const playMode = new PlayModeController(
      this.engineCore.scene,
      this.graph,
      this.store,
      this.engineCore.editorCamera
    );

    new ConsolePanel(root.querySelector('.console-row') as HTMLElement, this.store);
    new HierarchyPanel(root.querySelector('.hierarchy-col') as HTMLElement, this.graph, this.store, (id) =>
      this.deleteEntity(id)
    );
    new InspectorPanel(root.querySelector('.inspector-col') as HTMLElement, this.graph, this.store);

    const assetBrowser = new AssetBrowserPanel(
      root.querySelector('.asset-row') as HTMLElement,
      this.assetDb,
      this.store
    );

    const callbacks = {
      onDeleteSelected: () => this.deleteSelected(),
      onFocusSelected: () => this.focusSelected()
    };

    new Toolbar(
      root.querySelector('.toolbar-row') as HTMLElement,
      this.engineCore,
      this.graph,
      this.store,
      playMode,
      this.gizmoController,
      callbacks
    );

    new Viewport(viewportCol, this.engineCore, this.graph, this.store, this.gizmoController, callbacks);
    this.wireAssetDrop(canvas, assetBrowser);

    const hierarchyResizer = root.querySelector('[data-resizer="hierarchy"]') as HTMLElement;
    const inspectorResizer = root.querySelector('[data-resizer="inspector"]') as HTMLElement;
    makeHorizontallyResizable(root.querySelector('.hierarchy-col') as HTMLElement, hierarchyResizer, 'right');
    makeHorizontallyResizable(root.querySelector('.inspector-col') as HTMLElement, inspectorResizer, 'left');

    this.engineCore.start();
    this.seedDefaultScene();
    this.store.log('info', 'Engine başlatıldı — WebGL2 render pipeline aktif');
  }

  /** Asset Browser'dan viewport'a sürüklenen asset'i gerçekten sahneye uygular. */
  private wireAssetDrop(canvas: HTMLCanvasElement, assetBrowser: AssetBrowserPanel): void {
    canvas.addEventListener('dragover', (e) => {
      if (e.dataTransfer?.types.includes('text/plain')) {
        e.preventDefault();
        canvas.parentElement?.classList.add('drag-over');
      }
    });
    canvas.addEventListener('dragleave', () => canvas.parentElement?.classList.remove('drag-over'));

    canvas.addEventListener('drop', (e) => {
      const assetId = e.dataTransfer?.getData('text/plain');
      canvas.parentElement?.classList.remove('drag-over');
      if (!assetId) return;
      e.preventDefault();

      const record = assetBrowser.getAssetById(assetId);
      if (!record) return;

      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const pick = this.engineCore.scene.pick(x, y);

      if (record.type === 'model') {
        importModelAsset(this.engineCore.scene, this.graph, record)
          .then((entity) => {
            if (pick?.hit && pick.pickedPoint) {
              entity.transform.setPositionXYZ(pick.pickedPoint.x, pick.pickedPoint.y, pick.pickedPoint.z);
            }
            this.store.setSelection([entity.id]);
            this.store.log('info', `${record.name} sahneye import edildi`);
          })
          .catch((err) => this.store.log('error', `${record.name} import edilemedi: ${String(err)}`));
      } else if (record.type === 'texture') {
        const entityId = pick?.pickedMesh?.parent?.metadata?.entityId as string | undefined;
        const entity = entityId ? this.graph.entities.get(entityId) : undefined;
        if (entity && applyTextureToEntity(this.engineCore.scene, entity, record)) {
          this.store.log('info', `${record.name} dokusu ${entity.name} objesine uygulandı`);
        } else {
          this.store.log('warn', 'Doku uygulamak için bir mesh üzerine bırakın');
        }
      } else if (record.type === 'environment') {
        applyEnvironment(this.engineCore.scene, record);
        this.store.log('info', `${record.name} ortam ışığı olarak ayarlandı`);
      }
    });
  }

  private seedDefaultScene(): void {
    const cube = createPrimitiveEntity(this.engineCore.scene, this.graph, 'cube');
    cube.transform.setPositionXYZ(0, 0.5, 0);

    const light = createLightEntity(this.engineCore.scene, this.graph, 'directional');
    light.transform.setRotationXYZ(Math.PI / 3, Math.PI / 4, 0);

    this.store.setSelection([cube.id]);
  }

  private deleteSelected(): void {
    [...this.store.selectedIds].forEach((id) => this.deleteEntity(id));
  }

  private deleteEntity(id: string): void {
    const entity = this.graph.entities.get(id);
    if (!entity) return;
    this.store.log('info', `${entity.name} silindi`);
    this.graph.remove(id);
    this.store.setSelection(this.store.selectedIds.filter((sid) => sid !== id));
  }

  private focusSelected(): void {
    const [id] = this.store.selectedIds;
    const entity = id ? this.graph.entities.get(id) : undefined;
    if (!entity) return;
    entity.node.computeWorldMatrix(true);
    const pos = entity.node.getAbsolutePosition();
    this.engineCore.editorCamera.target.copyFrom(pos);
    this.engineCore.editorCamera.radius = 6;
  }
}
