import { EditorStore } from '../../state/EditorStore';
import { AssetDatabase, StoredAssetRecord } from '../../assets/AssetDatabase';
import { AssetKind, detectAssetKind } from '../../assets/AssetTypes';

export class AssetBrowserPanel {
  private el: HTMLElement;
  private gridEl: HTMLElement;
  private fileInput: HTMLInputElement;
  private assetsById = new Map<string, StoredAssetRecord>();

  constructor(container: HTMLElement, private db: AssetDatabase, private store: EditorStore) {
    this.el = document.createElement('div');
    this.el.className = 'panel asset-browser-panel';
    this.el.innerHTML = `
      <div class="panel-header asset-browser-header">
        <span>Asset Browser</span>
        <button type="button" class="asset-import-button">+ Import</button>
      </div>
      <div class="asset-grid"></div>
      <div class="asset-dropzone-hint">Sürükle-bırak: .glb .gltf .png .jpg .webp .hdr — asset'i viewport'a sürükleyerek sahneye uygula</div>
    `;
    container.appendChild(this.el);
    this.gridEl = this.el.querySelector('.asset-grid')!;

    this.fileInput = document.createElement('input');
    this.fileInput.type = 'file';
    this.fileInput.multiple = true;
    this.fileInput.accept = '.glb,.gltf,.png,.jpg,.jpeg,.webp,.hdr';
    this.fileInput.style.display = 'none';
    this.el.appendChild(this.fileInput);

    const importButton = this.el.querySelector('.asset-import-button') as HTMLButtonElement;
    importButton.addEventListener('click', () => this.fileInput.click());
    this.fileInput.addEventListener('change', () => {
      if (this.fileInput.files) this.importFiles(this.fileInput.files);
      this.fileInput.value = '';
    });

    this.el.addEventListener('dragover', (e) => {
      if (e.dataTransfer?.types.includes('Files')) {
        e.preventDefault();
        this.el.classList.add('drag-over');
      }
    });
    this.el.addEventListener('dragleave', () => this.el.classList.remove('drag-over'));
    this.el.addEventListener('drop', (e) => {
      if (!e.dataTransfer?.files.length) return;
      e.preventDefault();
      this.el.classList.remove('drag-over');
      this.importFiles(e.dataTransfer.files);
    });

    this.loadExisting();
  }

  /** Viewport'un drop handler'ı sürüklenen asset'i bulmak için kullanır. */
  getAssetById(id: string): StoredAssetRecord | undefined {
    return this.assetsById.get(id);
  }

  private async loadExisting(): Promise<void> {
    try {
      const records = await this.db.listAssets();
      records.forEach((record) => this.addToGrid(record));
    } catch (err) {
      this.store.log('warn', `Kayıtlı asset'ler okunamadı: ${String(err)}`);
    }
  }

  private async importFiles(files: FileList): Promise<void> {
    for (const file of Array.from(files)) {
      const kind = detectAssetKind(file.name);
      if (!kind) {
        this.store.log('warn', `${file.name} desteklenmeyen dosya tipi, atlandı`);
        continue;
      }
      try {
        const record = await this.db.addAsset(file, kind);
        this.addToGrid(record);
        this.store.log('info', `${file.name} asset kütüphanesine eklendi`);
      } catch (err) {
        this.store.log('error', `${file.name} eklenemedi: ${String(err)}`);
      }
    }
  }

  private addToGrid(record: StoredAssetRecord): void {
    this.assetsById.set(record.id, record);

    const card = document.createElement('div');
    card.className = 'asset-card';
    card.draggable = true;
    card.title = `${record.name} (${formatBytes(record.size)})`;

    const thumb = document.createElement('div');
    thumb.className = 'asset-thumb';
    if (record.type === 'texture') {
      const img = document.createElement('img');
      img.src = URL.createObjectURL(record.blob);
      thumb.appendChild(img);
    } else {
      thumb.textContent = iconFor(record.type);
    }

    const label = document.createElement('div');
    label.className = 'asset-label';
    label.textContent = record.name;

    card.appendChild(thumb);
    card.appendChild(label);

    card.addEventListener('dragstart', (e) => {
      e.dataTransfer?.setData('text/plain', record.id);
      if (e.dataTransfer) e.dataTransfer.effectAllowed = 'copy';
    });

    card.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      this.showDeleteMenu(e as MouseEvent, record, card);
    });

    this.gridEl.appendChild(card);
  }

  private showDeleteMenu(e: MouseEvent, record: StoredAssetRecord, card: HTMLElement): void {
    document.querySelector('.context-menu')?.remove();

    const menu = document.createElement('div');
    menu.className = 'context-menu';
    menu.style.left = `${e.clientX}px`;
    menu.style.top = `${e.clientY}px`;

    const del = document.createElement('div');
    del.className = 'context-menu-item';
    del.textContent = 'Delete';
    del.addEventListener('click', async () => {
      await this.db.deleteAsset(record.id);
      this.assetsById.delete(record.id);
      card.remove();
      menu.remove();
      this.store.log('info', `${record.name} asset kütüphanesinden silindi`);
    });
    menu.appendChild(del);
    document.body.appendChild(menu);

    const closeMenu = (ev: MouseEvent) => {
      if (!menu.contains(ev.target as Node)) {
        menu.remove();
        document.removeEventListener('click', closeMenu);
      }
    };
    setTimeout(() => document.addEventListener('click', closeMenu), 0);
  }
}

function iconFor(kind: AssetKind): string {
  switch (kind) {
    case 'model':
      return '🧊';
    case 'environment':
      return '🌅';
    default:
      return '📄';
  }
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
