import { Color3, Vector3 } from '@babylonjs/core';
import { SceneGraph } from '../../scene/SceneGraph';
import { EditorStore } from '../../state/EditorStore';
import { Entity } from '../../scene/Entity';

export class InspectorPanel {
  private el: HTMLElement;
  private body: HTMLElement;
  private unsubscribeTransform: (() => void) | null = null;

  constructor(container: HTMLElement, private graph: SceneGraph, private store: EditorStore) {
    this.el = document.createElement('div');
    this.el.className = 'panel inspector-panel';
    this.el.innerHTML = `<div class="panel-header">Inspector</div><div class="inspector-body"></div>`;
    container.appendChild(this.el);
    this.body = this.el.querySelector('.inspector-body')!;

    this.store.on('selectionChanged', () => this.render());
    this.render();
  }

  private currentEntity(): Entity | undefined {
    const [id] = this.store.selectedIds;
    return id ? this.graph.entities.get(id) : undefined;
  }

  private render(): void {
    this.unsubscribeTransform?.();
    this.unsubscribeTransform = null;
    this.body.innerHTML = '';

    if (this.store.selectedIds.length > 1) {
      this.body.innerHTML = `<div class="inspector-empty">${this.store.selectedIds.length} obje seçildi</div>`;
      return;
    }

    const entity = this.currentEntity();
    if (!entity) {
      this.body.innerHTML = `<div class="inspector-empty">Hiçbir obje seçili değil</div>`;
      return;
    }

    this.body.appendChild(this.buildHeaderSection(entity));
    this.body.appendChild(this.buildTransformSection(entity));

    if (entity.components.meshRenderer) this.body.appendChild(this.buildMeshRendererSection(entity));
    if (entity.components.light) this.body.appendChild(this.buildLightSection(entity));
    if (entity.components.camera) this.body.appendChild(this.buildCameraSection(entity));
    if (entity.components.importedModel) this.body.appendChild(this.buildImportedModelSection(entity));

    this.unsubscribeTransform = entity.transform.on('change', () => this.refreshTransformInputs(entity));
  }

  private section(title: string): HTMLElement {
    const wrap = document.createElement('div');
    wrap.className = 'inspector-section';
    const header = document.createElement('div');
    header.className = 'inspector-section-header';
    header.textContent = title;
    wrap.appendChild(header);
    return wrap;
  }

  private numberField(label: string, value: number, onChange: (v: number) => void): HTMLElement {
    const row = document.createElement('label');
    row.className = 'inspector-field';
    const span = document.createElement('span');
    span.textContent = label;
    const input = document.createElement('input');
    input.type = 'number';
    input.step = '0.1';
    input.value = value.toFixed(3);
    input.addEventListener('change', () => onChange(parseFloat(input.value) || 0));
    row.appendChild(span);
    row.appendChild(input);
    return row;
  }

  private vectorRow(label: string, vector: Vector3, onChange: (axis: 'x' | 'y' | 'z', v: number) => void): HTMLElement {
    const row = document.createElement('div');
    row.className = 'inspector-vector-row';
    const title = document.createElement('span');
    title.className = 'inspector-vector-label';
    title.textContent = label;
    row.appendChild(title);
    (['x', 'y', 'z'] as const).forEach((axis) => {
      const input = document.createElement('input');
      input.type = 'number';
      input.step = '0.1';
      input.className = `inspector-axis-input axis-${axis}`;
      input.dataset.axis = axis;
      input.value = vector[axis].toFixed(3);
      input.addEventListener('change', () => onChange(axis, parseFloat(input.value) || 0));
      row.appendChild(input);
    });
    return row;
  }

  private buildHeaderSection(entity: Entity): HTMLElement {
    const wrap = document.createElement('div');
    wrap.className = 'inspector-header-section';

    const nameInput = document.createElement('input');
    nameInput.className = 'inspector-name-input';
    nameInput.value = entity.name;
    nameInput.addEventListener('change', () =>
      this.graph.rename(entity.id, nameInput.value.trim() || entity.name)
    );

    const activeLabel = document.createElement('label');
    activeLabel.className = 'inspector-active-toggle';
    const activeCheckbox = document.createElement('input');
    activeCheckbox.type = 'checkbox';
    activeCheckbox.checked = entity.active;
    activeCheckbox.addEventListener('change', () => {
      entity.active = activeCheckbox.checked;
      entity.node.setEnabled(entity.active);
    });
    activeLabel.appendChild(activeCheckbox);
    activeLabel.appendChild(document.createTextNode('Active'));

    wrap.appendChild(nameInput);
    wrap.appendChild(activeLabel);
    return wrap;
  }

  private buildTransformSection(entity: Entity): HTMLElement {
    const section = this.section('Transform');
    section.dataset.section = 'transform';
    section.appendChild(
      this.vectorRow('Position', entity.transform.position, (axis, v) => {
        entity.transform.position[axis] = v;
        entity.transform.notify();
      })
    );
    section.appendChild(
      this.vectorRow('Rotation °', entity.transform.rotation, (axis, v) => {
        entity.transform.rotation[axis] = (v * Math.PI) / 180;
        entity.transform.notify();
      })
    );
    section.appendChild(
      this.vectorRow('Scale', entity.transform.scaling, (axis, v) => {
        entity.transform.scaling[axis] = v;
        entity.transform.notify();
      })
    );
    return section;
  }

  private refreshTransformInputs(entity: Entity): void {
    const section = this.body.querySelector('[data-section="transform"]');
    if (!section) return;
    const rows = section.querySelectorAll('.inspector-vector-row');
    const data = [entity.transform.position, entity.transform.rotation, entity.transform.scaling];
    rows.forEach((row, idx) => {
      const vec = data[idx];
      const isRotation = idx === 1;
      row.querySelectorAll('input').forEach((input) => {
        if (document.activeElement === input) return;
        const axis = input.dataset.axis as 'x' | 'y' | 'z';
        const raw = vec[axis];
        input.value = (isRotation ? (raw * 180) / Math.PI : raw).toFixed(3);
      });
    });
  }

  private buildMeshRendererSection(entity: Entity): HTMLElement {
    const section = this.section('Mesh Renderer');
    const renderer = entity.components.meshRenderer!;

    const colorRow = document.createElement('label');
    colorRow.className = 'inspector-field';
    const span = document.createElement('span');
    span.textContent = 'Base Color';
    const colorInput = document.createElement('input');
    colorInput.type = 'color';
    colorInput.value = colorToHex(renderer.material.diffuseColor);
    colorInput.addEventListener('input', () => {
      renderer.material.diffuseColor = hexToColor3(colorInput.value);
    });
    colorRow.appendChild(span);
    colorRow.appendChild(colorInput);
    section.appendChild(colorRow);

    const wireframeRow = document.createElement('label');
    wireframeRow.className = 'inspector-field';
    const wSpan = document.createElement('span');
    wSpan.textContent = 'Wireframe';
    const wCheckbox = document.createElement('input');
    wCheckbox.type = 'checkbox';
    wCheckbox.checked = renderer.material.wireframe;
    wCheckbox.addEventListener('change', () => renderer.setWireframe(wCheckbox.checked));
    wireframeRow.appendChild(wSpan);
    wireframeRow.appendChild(wCheckbox);
    section.appendChild(wireframeRow);

    return section;
  }

  private buildLightSection(entity: Entity): HTMLElement {
    const light = entity.components.light!;
    const section = this.section(`Light (${light.kind})`);

    const colorRow = document.createElement('label');
    colorRow.className = 'inspector-field';
    const span = document.createElement('span');
    span.textContent = 'Color';
    const colorInput = document.createElement('input');
    colorInput.type = 'color';
    colorInput.value = colorToHex(light.color);
    colorInput.addEventListener('input', () => (light.color = hexToColor3(colorInput.value)));
    colorRow.appendChild(span);
    colorRow.appendChild(colorInput);
    section.appendChild(colorRow);

    section.appendChild(this.numberField('Intensity', light.intensity, (v) => (light.intensity = v)));
    if (light.kind === 'point' || light.kind === 'spot') {
      section.appendChild(this.numberField('Range', light.range, (v) => (light.range = v)));
    }
    return section;
  }

  private buildCameraSection(entity: Entity): HTMLElement {
    const cam = entity.components.camera!;
    const section = this.section('Camera');
    section.appendChild(this.numberField('Field of View', cam.fov, (v) => (cam.fov = v)));
    section.appendChild(this.numberField('Near Clip', cam.nearClip, (v) => (cam.nearClip = v)));
    section.appendChild(this.numberField('Far Clip', cam.farClip, (v) => (cam.farClip = v)));
    return section;
  }

  private buildImportedModelSection(entity: Entity): HTMLElement {
    const model = entity.components.importedModel!;
    const section = this.section('Imported Model');
    const info = document.createElement('div');
    info.className = 'inspector-readonly-note';
    info.textContent = `Kaynak: ${model.sourceName} — ${model.meshes.length} mesh`;
    section.appendChild(info);
    return section;
  }
}

function colorToHex(color: Color3): string {
  const toHex = (c: number) => Math.round(Math.min(1, Math.max(0, c)) * 255).toString(16).padStart(2, '0');
  return `#${toHex(color.r)}${toHex(color.g)}${toHex(color.b)}`;
}

function hexToColor3(hex: string): Color3 {
  const r = parseInt(hex.slice(1, 3), 16) / 255;
  const g = parseInt(hex.slice(3, 5), 16) / 255;
  const b = parseInt(hex.slice(5, 7), 16) / 255;
  return new Color3(r, g, b);
}
