import { Scene, SceneLoader, Texture, HDRCubeTexture } from '@babylonjs/core';
import { SceneGraph } from '../scene/SceneGraph';
import { Entity } from '../scene/Entity';
import { createEmptyEntity } from './PrimitiveFactory';
import { ImportedModelComponent } from '../components/ImportedModelComponent';
import { StoredAssetRecord } from '../assets/AssetDatabase';

/** Bir .glb/.gltf asset'ini gerçekten sahneye import eder ve yeni bir Entity döner. */
export async function importModelAsset(
  scene: Scene,
  graph: SceneGraph,
  record: StoredAssetRecord
): Promise<Entity> {
  const file = new File([record.blob], record.name, { type: record.mimeType });
  const extension = record.name.toLowerCase().endsWith('.glb') ? '.glb' : '.gltf';

  const result = await SceneLoader.ImportMeshAsync('', '', file, scene, undefined, extension);

  const entity = createEmptyEntity(scene, graph);
  graph.rename(entity.id, record.name.replace(/\.(glb|gltf)$/i, ''));
  entity.components.importedModel = new ImportedModelComponent(record.name, result.meshes, entity.node);
  return entity;
}

/** Bir texture asset'ini seçili entity'nin gerçek material'ına uygular. */
export function applyTextureToEntity(scene: Scene, entity: Entity, record: StoredAssetRecord): boolean {
  const renderer = entity.components.meshRenderer;
  if (!renderer) return false;
  const url = URL.createObjectURL(record.blob);
  renderer.material.diffuseTexture = new Texture(url, scene);
  return true;
}

/** Bir .hdr asset'ini sahnenin gerçek ortam ışığı (environment) olarak ayarlar. */
export function applyEnvironment(scene: Scene, record: StoredAssetRecord): void {
  const url = URL.createObjectURL(record.blob);
  scene.environmentTexture = new HDRCubeTexture(url, scene, 128);
}
