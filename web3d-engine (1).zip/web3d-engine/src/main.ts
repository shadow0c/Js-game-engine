import './style.css';
import '@babylonjs/loaders/glTF';
import { EditorApp } from './editor/EditorApp';

function isWebGL2Supported(): boolean {
  try {
    const canvas = document.createElement('canvas');
    return !!canvas.getContext('webgl2');
  } catch {
    return false;
  }
}

function showFatalError(root: HTMLElement, message: string): void {
  root.innerHTML = `<div class="fatal-error"><h2>Motor başlatılamadı</h2><p>${message}</p></div>`;
}

function bootstrap(): void {
  const root = document.getElementById('app');
  if (!root) {
    console.error('#app kök elementi bulunamadı.');
    return;
  }

  if (!isWebGL2Supported()) {
    showFatalError(
      root,
      'Bu tarayıcı WebGL2 desteklemiyor. Lütfen güncel bir Chrome, Edge veya Firefox sürümü kullanın.'
    );
    return;
  }

  try {
    new EditorApp(root);
  } catch (error) {
    console.error(error);
    showFatalError(root, error instanceof Error ? error.message : 'Bilinmeyen bir hata oluştu.');
  }
}

window.addEventListener('error', (event) => {
  console.error(`Beklenmeyen hata: ${event.message}`);
});
window.addEventListener('unhandledrejection', (event) => {
  console.error(`Yakalanmayan promise hatası: ${String(event.reason)}`);
});

window.addEventListener('DOMContentLoaded', bootstrap);
