import { TransformNode, Scene } from '@babylonjs/core';
import { createId } from '../core/id';
import { TransformComponent } from '../components/TransformComponent';
import { MeshRendererComponent } from '../components/MeshRendererComponent';
import { CameraComponent } from '../components/CameraComponent';
import { LightComponent } from '../components/LightComponent';
import { ImportedModelComponent } from '../components/ImportedModelComponent';

export type PrimitiveKind = 'cube' | 'sphere' | 'plane' | 'cylinder' | 'capsule' | 'cone' | 'torus';

export interface EntityComponents {
  meshRenderer?: MeshRendererComponent;
  camera?: CameraComponent;
  light?: LightComponent;
  importedModel?: ImportedModelComponent;
}

export class Entity {
  readonly id: string;
  name: string;
  active = true;
  readonly node: TransformNode;
  readonly transform: TransformComponent;
  parent: Entity | null = null;
  readonly children: Entity[] = [];
  readonly components: EntityComponents = {};

  constructor(scene: Scene, name: string) {
    this.id = createId('ent');
    this.name = name;
    this.node = new TransformNode(name, scene);
    this.node.metadata = { entityId: this.id };
    this.transform = new TransformComponent(this.node);

    // Transform her değiştiğinde (gizmo drag, Inspector, script...) bağlı
    // camera/light component'lerini gerçek dünya pozisyonuna senkronize et.
    this.transform.on('change', () => {
      this.components.camera?.syncFromNode();
      this.components.light?.syncFromNode();
    });
  }

  setParent(parent: Entity | null): void {
    if (this.parent) {
      const idx = this.parent.children.indexOf(this);
      if (idx >= 0) this.parent.children.splice(idx, 1);
    }
    this.parent = parent;
    this.node.parent = parent ? parent.node : null;
    if (parent) parent.children.push(this);
  }

  dispose(): void {
    this.components.meshRenderer?.dispose();
    this.components.camera?.dispose();
    this.components.light?.dispose();
    this.components.importedModel?.dispose();
    this.node.dispose();
  }
}
